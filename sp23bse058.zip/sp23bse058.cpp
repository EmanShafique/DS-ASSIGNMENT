#include <iostream>
#include <string>
using namespace std;

// Structure to represent a task
struct Task {
    int taskId;            // Task ID to uniquely identify a task
    string description;    // Short description of the task
    int priority;          // Priority level of the task (higher value = higher priority)
    Task* next;            // Pointer to the next task in the list
};

// Structure to represent the task list using a linked list
struct TaskList {
    Task* head;  // Pointer to the first task in the list

    // Constructor to initialize the task list with no tasks (head is null)
    TaskList() : head(nullptr) {}

    // Function to add a new task to the list in descending order of priority
    void addTask(int id, string description, int priority) {
        Task* newTask = new Task;  // Create a new task dynamically
        newTask->taskId = id;      // Assign the task ID
        newTask->description = description;  // Assign the task description
        newTask->priority = priority;  // Assign the task priority
        newTask->next = nullptr;  // Initialize the next pointer to null

        // If the list is empty or the new task has a higher priority than the head
        if (head == nullptr || newTask->priority > head->priority) {
            newTask->next = head;  // Insert the new task at the head
            head = newTask;        // Update the head to the new task
        } else {
            // Traverse the list to find the correct position for the new task
            Task* current = head;
            while (current->next != nullptr && current->next->priority > newTask->priority) {
                current = current->next;
            }
            newTask->next = current->next;  // Insert the new task in the correct position
            current->next = newTask;        // Link the new task to the list
        }
    }

    // Function to remove the task with the highest priority (the head of the list)
    void removeHighestPriorityTask() {
        if (head != nullptr) {
            Task* temp = head;  // Store the current head temporarily
            head = head->next;  // Move the head to the next task in the list
            delete temp;        // Delete the old head
            cout << "Highest priority task removed." << endl;
        } else {
            cout << "No tasks to remove." << endl;  // If the list is empty
        }
    }

    // Function to remove a task by its ID
    void removeTaskById(int id) {
        if (head == nullptr) {  // If the list is empty
            cout << "Task list is empty." << endl;
            return;
        }
        if (head->taskId == id) {  // If the task to be removed is the head
            Task* temp = head;     // Store the head temporarily
            head = head->next;     // Move the head to the next task
            delete temp;           // Delete the old head
            cout << "Task with ID " << id << " removed." << endl;
            return;
        }

        // Traverse the list to find the task by ID
        Task* current = head;
        while (current->next != nullptr) {
            if (current->next->taskId == id) {
                Task* temp = current->next;  // Store the task to be removed
                current->next = temp->next;  // Unlink the task from the list
                delete temp;                 // Delete the task
                cout << "Task with ID " << id << " removed." << endl;
                return;
            }
            current = current->next;
        }
        cout << "Task with ID " << id << " not found." << endl;  // If the task is not found
    }

    // Function to view all tasks in the list
    void viewAllTasks() const {
        if (head == nullptr) {  // If the list is empty
            cout << "No tasks in the list." << endl;
            return;
        }

        // Traverse the list and display each task's details
        Task* current = head;
        while (current != nullptr) {
            cout << "Task ID: " << current->taskId << endl;
            cout << "Description: " << current->description << endl;
            cout << "Priority: " << current->priority << endl;
            cout << endl;
            current = current->next;  // Move to the next task in the list
        }
    }
};

// Main function to interact with the user
int main() {
    TaskList taskList;  // Create an instance of the TaskList
    int choice;         // Variable to store user's menu choice

    // Loop to repeatedly display the menu and take user input
    while (true) {
        cout << "1. Add a new task" << endl;
        cout << "2. View all tasks" << endl;
        cout << "3. Remove the highest priority task" << endl;
        cout << "4. Remove a task by ID" << endl;
        cout << "5. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;  // Get the user's choice

        // Switch statement to perform the selected operation
        switch (choice) {
            case 1: {
                int id, priority;
                string description;
                cout << "Enter task ID: ";
                cin >> id;              // Get task ID from the user
                cin.ignore();           // Ignore the newline character
                cout << "Enter task description: ";
                getline(cin, description);  // Get task description from the user
                cout << "Enter priority level: ";
                cin >> priority;        // Get task priority from the user
                taskList.addTask(id, description, priority);  // Add the task to the list
                break;
            }
            case 2:
                taskList.viewAllTasks();  // Display all tasks
                break;
            case 3:
                taskList.removeHighestPriorityTask();  // Remove the highest priority task
                break;
            case 4: {
                int id;
                cout << "Enter task ID to remove: ";
                cin >> id;  // Get the ID of the task to be removed
                taskList.removeTaskById(id);  // Remove the task by ID
                break;
            }
            case 5:
                return 0;  // Exit the program
            default:
                cout << "Invalid choice. Please try again." << endl;  // Invalid menu choice
        }
    }
    return 0;
}